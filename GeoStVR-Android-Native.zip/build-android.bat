@echo off
echo ========================================
echo    GeoStVR - Build Android APK
echo ========================================
echo.

echo [1/5] Instalando dependencias...
call npm install

echo.
echo [2/5] Sincronizando con Capacitor...
call npx cap sync android

echo.
echo [3/5] Construyendo proyecto Android...
call npx cap build android

echo.
echo [4/5] Generando APK de debug...
cd android
call .\gradlew assembleDebug
cd ..

echo.
echo [5/5] APK generado exitosamente!
echo.
echo El APK se encuentra en:
echo GeoStVR-Android\android\app\build\outputs\apk\debug\app-debug.apk
echo.
echo Puedes transferir este archivo a tu dispositivo Android
echo e instalarlo directamente.
echo.
pause
