# GeoStVR - Aplicación Android Nativa

## 📱 Descripción

GeoStVR es una aplicación nativa Android para medir ángulos de calce entre BOHs usando la cámara del dispositivo. La aplicación funciona de forma completamente independiente, sin necesidad de navegador web.

## 🚀 Características

- **Aplicación nativa Android** - Funciona standalone sin navegador
- **Cámara AR integrada** - Acceso directo a la cámara del dispositivo
- **Medición de ángulos** - Sistema de captura de puntos y cálculos
- **Interfaz táctil optimizada** - Diseñada específicamente para móviles
- **Funcionamiento offline** - No requiere conexión a internet

## 🛠️ Requisitos del Sistema

### Para desarrollo:
- Node.js 16+ y npm
- Android Studio 4.0+
- Android SDK API 21+
- Java JDK 11+

### Para el dispositivo:
- Android 5.0+ (API 21+)
- Cámara trasera
- 100MB de espacio libre

## 📋 Instalación y Construcción

### Opción 1: Script automatizado (Recomendado)

1. **Ejecuta el script de construcción:**
   ```bash
   build-android.bat
   ```

2. **El script realizará automáticamente:**
   - Instalación de dependencias
   - Sincronización con Capacitor
   - Construcción del proyecto Android
   - Generación del APK

3. **El APK se generará en:**
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

### Opción 2: Comandos manuales

1. **Instalar dependencias:**
   ```bash
   npm install
   ```

2. **Sincronizar con Capacitor:**
   ```bash
   npx cap sync android
   ```

3. **Construir proyecto Android:**
   ```bash
   npx cap build android
   ```

4. **Generar APK:**
   ```bash
   cd android
   ./gradlew assembleDebug
   cd ..
   ```

## 📱 Instalación en Dispositivo

### Método 1: Transferencia directa
1. Conecta tu dispositivo Android a la PC
2. Copia el archivo `app-debug.apk` al dispositivo
3. En Android, ve a **Configuración > Seguridad**
4. Activa **"Fuentes desconocidas"**
5. Abre el archivo APK y toca **"Instalar"**

### Método 2: ADB (Android Debug Bridge)
1. Conecta el dispositivo en modo desarrollador
2. Ejecuta: `adb install app-debug.apk`

### Método 3: Android Studio
1. Abre el proyecto en Android Studio
2. Conecta tu dispositivo
3. Presiona **"Run"** (▶️)

## 🔧 Configuración del Proyecto

### Archivos principales:
- `www/index.html` - Interfaz de usuario
- `capacitor.config.ts` - Configuración de Capacitor
- `android/app/src/main/AndroidManifest.xml` - Manifesto Android
- `package.json` - Dependencias del proyecto

### Personalización:
- **Nombre de la app:** Modifica `appName` en `capacitor.config.ts`
- **ID del paquete:** Cambia `appId` en `capacitor.config.ts`
- **Icono:** Reemplaza `android/app/src/main/res/mipmap/ic_launcher.png`
- **Colores:** Modifica `android/app/src/main/res/values/colors.xml`

## 📊 Estructura del Proyecto

```
GeoStVR-Android/
├── www/                          # Assets web
│   ├── index.html               # Aplicación principal
│   ├── manifest.json            # PWA manifest
│   └── sw.js                    # Service worker
├── android/                      # Proyecto Android nativo
│   └── app/src/main/
│       ├── AndroidManifest.xml  # Permisos y configuración
│       └── java/                # Código Java nativo
├── capacitor.config.ts          # Configuración Capacitor
├── package.json                 # Dependencias npm
└── build-android.bat            # Script de construcción
```

## 🚨 Solución de Problemas

### Error: "npm no se reconoce"
- Instala Node.js desde: https://nodejs.org/
- Reinicia la terminal

### Error: "gradlew no se reconoce"
- Asegúrate de estar en el directorio `android/`
- Ejecuta: `chmod +x gradlew` (Linux/Mac)

### Error: "SDK no encontrado"
- Abre Android Studio
- Ve a **SDK Manager** e instala Android SDK
- Configura la variable de entorno `ANDROID_HOME`

### Error: "Permisos insuficientes"
- Ejecuta PowerShell como Administrador
- Ejecuta: `Set-ExecutionPolicy RemoteSigned`

## 📞 Soporte

Si encuentras problemas:
1. Verifica que todas las dependencias estén instaladas
2. Asegúrate de tener Android Studio configurado
3. Revisa los logs de error en la consola
4. Verifica que el dispositivo esté en modo desarrollador

## 🎯 Próximos Pasos

Una vez que la aplicación esté funcionando:
- Personaliza la interfaz según tus necesidades
- Agrega funcionalidades adicionales
- Optimiza el rendimiento
- Implementa cálculos reales de ángulos
- Agrega persistencia de datos

---

**¡GeoStVR está listo para funcionar como una aplicación nativa Android!** 🎉
