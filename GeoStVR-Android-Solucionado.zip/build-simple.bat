@echo off
echo ========================================
echo    GeoStVR - Build Simple Android
echo ========================================
echo.

echo [1/3] Verificando Capacitor...
where npx >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: npx no encontrado. Instala Node.js y npm primero.
    echo Descarga desde: https://nodejs.org/
    pause
    exit /b 1
)

echo [2/3] Sincronizando con Capacitor...
npx cap sync android
if %errorlevel% neq 0 (
    echo ERROR: Fallo en la sincronización de Capacitor
    pause
    exit /b 1
)

echo [3/3] Abriendo en Android Studio...
npx cap open android
if %errorlevel% neq 0 (
    echo ERROR: No se pudo abrir Android Studio
    echo Asegúrate de tener Android Studio instalado
    pause
    exit /b 1
)

echo.
echo ========================================
echo    INSTRUCCIONES PARA COMPLETAR
echo ========================================
echo.
echo 1. Android Studio se abrirá automáticamente
echo 2. Espera a que se sincronice el proyecto
echo 3. Conecta tu dispositivo Android
echo 4. Presiona el botón "Run" (▶️)
echo 5. Selecciona tu dispositivo y presiona OK
echo.
echo El APK se instalará directamente en tu dispositivo
echo.
pause
